Direct Resize
~~~~~~~~~~~~~

A modx revo plugin to apply the highslide (www.highslide.js) image expander to any images in modx Revo.

IMPORTANT NOTE: Highslide JS is licensed under a Creative Commons Attribution-NonCommercial 2.5 License. This means you need the author's permission to use Highslide JS on commercial websites.

Whilst free for personal and non-profit organisations, if you are using highslide for a commercial site then you must purchase a license.

Installation
~~~~~~~~~~~~
Via the package manager it should install all the required files. All the options for the plugin can be found on the properties tab for the plugin. If enable is set to 2 then it should work straight out of the box for all images under the directory '/assets/images' . 

Credits
~~~~~~~
I can make little claim for the plugin having just built on the work done previously. At the moment it's a poor imitation of the original DirectResize plugin, it has just been updated to run highslide on modx revo.

Adrian Cherry
July 2011 
